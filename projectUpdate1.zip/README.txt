INST126 Project 4 COVID-19 Tracker

Project Goal:
Project goal is to create a thorough and detailed analysis covid cases, peaks and troughs in various counties, deaths vs recoveries, etc.


This project will use python pandas data analysis visualization tool to present COVID-19 Data. In regards to the code, we first need to index the data values, 
clean the data set, drop all extraneous values, and then drop all null values in the dataset. Pandas has various functions such as the dropna() and set_clean()
function to help us with this. The dataset will be collected by the part of our team tasked with research.

we plan to seperate various graphs, which represent different data, into functions. The user will get to pick which function they would like to run
As of now, we have 3 functions planned: Function to create a graph showcasing cases in days and months, fucntion to create a graph showcasing number of recorded 
recoveries in days and months, and a function showcasing deaths due to COVID-19 in days and months.

Each function will sort data by day and month, choose an appropriate range, then display the information. There could be plans in the future to seperate the days and months
into seperate functions as well.

A strong focus here is to make the data easy and accessible, meaning anyone can easily use the program and interpret the graphs.
